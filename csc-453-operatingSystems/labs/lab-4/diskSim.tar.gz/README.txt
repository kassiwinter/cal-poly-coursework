Kassi Winter
Progress: My program works correctly.
Special Instructions: 
    - Please use 'python3' to compile
    - Assumes the given sequence file will be located in the same directory as the program