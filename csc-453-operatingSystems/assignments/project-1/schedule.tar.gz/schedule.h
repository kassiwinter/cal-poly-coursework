#include <sys/types.h>

#ifndef SCHEDULER_H
#define SCHEDULER_H

#define MAX_PROCESSES 100
#define MAX_ARGUMENTS 10

typedef struct{
    pid_t pid;
    char* args[MAX_ARGUMENTS];
    int arg_num;
    int flag;
} Process;


#endif