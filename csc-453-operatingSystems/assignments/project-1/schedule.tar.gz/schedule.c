#include "schedule.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>

volatile sig_atomic_t timer_expired_flag = 0;
char* pass;

// A. Function to handle the alarm signal
void alarmHandler(int signum) {
   raise(SIGCONT);
}

// B. Function to parse command line arguments given
void parseArguments(int argc, char* argv[], Process process_list[MAX_PROCESSES], int* process_length) {
    int process_num = 0; // Counts the total number of processes
    int new_process_flag = 1; // Flag for if the parser hit a new process or not
    int i;

    
    for (i = 2; i < argc; i++) { // LOOK INTO 'argc - 1'
        if (strcmp(argv[i], ":") == 0) { // Hit a colon? Increment the number of processes & switch on the flag.
            if (process_num >= MAX_PROCESSES) { // CHECK - Does it exceed the max processes allowed?
                fprintf(stderr, "Error: Exceeded the maximum number of processes allowed.\n");
                exit(1);
            }
            process_num++;
            new_process_flag = 1;

        }

        else {
            if (new_process_flag) { // Is the process flag switched on? Create a new process structure & add to list.
                Process process;
                
                char* name_str = (char*)malloc(strlen(argv[i] + 2) * sizeof(char));
                strcpy(name_str, "./");
                strcat(name_str, argv[i]);

                process.arg_num = 0;
                process.flag = 0;
                (*process_length)++;

                process.args[process.arg_num] = name_str;
                process.arg_num++;

                int j;
                for (j = i + 1; j < argc && strcmp(argv[j], ":") != 0; j++) {
                    char* arg_str = (char*)malloc(strlen(argv[j]) * sizeof(char));
                    strcpy(arg_str, argv[j]);
                    process.args[process.arg_num] = arg_str;
                    process.arg_num++;

                    if (process.arg_num >= MAX_ARGUMENTS) { // CHECK - Does it exceed the max arguments allowed?
                        fprintf(stderr, "Error: Too many arguments for a process.\n");
                        exit(1);
                    }
                }

                process.args[process.arg_num] = NULL;
                process_list[process_num] = process;
                new_process_flag = 0;
            }
        }
    }
}

// C. Function to fork and initalize each child process, THEN run them
void runChildren(Process process_list[MAX_PROCESSES], int process_length) {
    int i;

    for (i = 0; i < (process_length); i++) { // Loop through all of the processes in list
        pid_t pid = fork();

        if (pid == -1) { // A. The Child Creation Failed
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0) { // B. The Child Creation Suceeded
            raise(SIGSTOP);
            Process process = process_list[i];
            if (process.arg_num == 1) {
                execvp(process.args[0], NULL);// Case #1: No argument case
            }
            else {
                execvp(process.args[0], process.args); // Case #2: Has at least one argument
            }

            perror("none of the exec matched"); // Some error happened when trying to execute the given process 
            exit(EXIT_FAILURE);
        }
        else {
            process_list[i].pid = pid;
        }


        //int status;
        //wait(&status);

        /* else {
            int status;
            if (waitpid(pid, &status, 0) == -1) {
                perror("error waitpiding in the child");
                exit(EXIT_FAILURE);
            }
            if (WIFEXITED(status)) {
                printf("child is sucessful");
                kill(getpid(), SIGCHLD)
            }
            else {
                perror("child execution failed");
                exit(EXIT_FAILURE);
            }
        } */

    }

}


// C. Function to Fork() each process for a given time
void roundRobinProcess(Process process_list[MAX_PROCESSES], int process_length, int quantum) {
    int index = 0;
    int active_processes = process_length;
    pid_t process_pid;
    int status;


    struct sigaction sa;
    sa.sa_handler = alarmHandler;
    if (sigaction(SIGALRM, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    struct itimerval timer;
    timer.it_value.tv_sec = quantum / 1000;;
    timer.it_value.tv_usec = (quantum % 1000) * 1000;
    timer.it_interval.tv_sec = quantum / 1000;;
    timer.it_interval.tv_usec = (quantum % 1000) * 1000;

    if (setitimer(ITIMER_REAL, &timer, NULL) == -1) {
        perror("setitimer");
        exit(EXIT_FAILURE);
    }

    while (active_processes > 0) {

        if (index >= process_length) { // CHECK - Is it time to round the Robin?
            index = 0;
        }

        Process current_process = process_list[index];
        if (current_process.flag == 1){
                index++;
        }
        else { // B. The given process is still running
            process_pid = current_process.pid;

            kill(process_pid, SIGCONT);


            int status;
            waitpid(process_pid, &status, WUNTRACED);
            kill(process_pid, SIGSTOP);
            waitpid(process_pid, &status, WUNTRACED);

            if (WIFEXITED(status)) {
                    current_process.flag = 1;
                    int j;
                    for (j = 0; current_process.args[j] != NULL; j++) {
                        fflush(stdout);
                        free(current_process.args[j]);
                    }
                    active_processes--;
            }
            
            index++;
        }
    }

        
}



// D. Main Function
int main(int argc, char* argv[]) {
    if ((argc < 3)) { // CHECK - Were no processes provided in the command line?
        fprintf(stderr, "Error: Not all information necissary is provided.\n");
        return 1;
    }

    if (atoi(argv[1]) <= 0) { // CHECK - Is the quantum value provided a number?
        fprintf(stderr, "Error: Quantum must be a positive integer.\n");
        return 1;
    }
    int quantum = atoi(argv[1]);
    int process_length = 0;

    Process process_list[MAX_PROCESSES];

     // Step # 1 - Parse through the command line to get programs
    parseArguments(argc, argv, process_list, &process_length);

    // Step # 2 - Looping through children & forking for them (program initalization / process creation)
    runChildren(process_list, process_length);

    // Step # 3 - Start going through each of the children & running them
    roundRobinProcess(process_list, process_length, quantum);

    
    return 0;
}