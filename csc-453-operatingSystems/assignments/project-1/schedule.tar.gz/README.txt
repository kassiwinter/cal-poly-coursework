Kassandra Winter

My program is working correctly (to the best of my knowledge..)
Please concider that I am trying my best!
